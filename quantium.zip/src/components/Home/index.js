import App from './Home';

export default App;